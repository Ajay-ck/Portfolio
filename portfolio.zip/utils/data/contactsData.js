export const contactsData = {
    email: 'ajaychekavarck@gmail.com',
    phone: '+91-9544643754',
    address: 'Tirur, Kerala, India',
    github: 'https://github.com/Ajay-ck',
    linkedIn: 'https://linkedin.com/in/ajay-ck'
}