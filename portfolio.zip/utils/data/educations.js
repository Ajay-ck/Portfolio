export const educations = [
  {
    id: 1,
    title: "Bachelor of Science (Physics)",
    duration: "2018 - 2021",
    institution: "Tunchan Memorial Government College Tirur, KL",
  },
  {
    id: 2,
    title: "Data Science and AI",
    duration: "Dec 2020 - June 2021",
    institution: "Social Prachar Hyderabad,TS",
  }
]