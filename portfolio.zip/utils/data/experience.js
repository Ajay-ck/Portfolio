export const experiences = [
  {
    id: 1,
    title: 'Conversational AI Engineer',
    company: "Botangelos",
    duration: "(August 2024 - Present)"
  },
  {
    id: 2,
    title: "Chatbot Developer",
    company: "Dewiride Tech. Pvt. Ltd",
    duration: "(August 2022 - August 2024)"
  },
  {
    id: 3,
    title: "SDE Intern",
    company: "Argoid Analytics",
    duration: "(Mar 2022 - July 2022)"
  },
  {
    id: 4,
    title: "Machine Learning Intern",
    company: "Grroom",
    duration: "(July 2021 - Sep 2021)"
  }
]